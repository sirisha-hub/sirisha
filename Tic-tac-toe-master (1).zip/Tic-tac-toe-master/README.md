# Tic-tac-toe
Tic-tac-toe game using Python

A proper documentation of the code and techniques at https://www.askpython.com/python/examples/tic-tac-toe-using-python
